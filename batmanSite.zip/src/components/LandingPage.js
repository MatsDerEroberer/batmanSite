import '../css/LandingPage.css'

const LandingPage = () => {
    
    return(
        <div className="LandingPage">
            <button>
                <span>I'm Vengeance</span>
            </button>
       </div>
    )
}

export default LandingPage
